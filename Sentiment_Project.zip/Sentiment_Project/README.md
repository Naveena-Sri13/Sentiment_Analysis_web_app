# Product Review Sentiment Analyzer

A web application that analyzes product review sentiment using Natural Language Processing (NLP).

## Features

- Single Review Analysis: Enter a review and get instant sentiment classification
- Batch CSV Upload: Upload a CSV file with reviews for bulk analysis
- Sentiment Classification: Positive, Negative, or Neutral
- Confidence Scores: Shows the intensity of detected sentiment
- Visualizations: Bar charts and pie charts for sentiment distribution
- VADER NLP: Uses NLTK VADER sentiment analyzer

## Tech Stack

- Python 3.9+
- Streamlit - Web framework
- NLTK (VADER) - Sentiment analysis
- Pandas - Data processing
- Plotly - Interactive visualizations

## Setup Instructions

### Prerequisites
- Python 3.9 or higher installed (https://python.org)
- pip (Python package manager, included with Python)

### Step-by-Step Setup

1. Clone or download this project
   cd sentiment-analyzer

2. Create a virtual environment (recommended)
   python -m venv venv

   On macOS/Linux:
   source venv/bin/activate

   On Windows:
   venv\Scripts\activate

3. Install dependencies
   pip install -r requirements.txt

4. Run the application
   streamlit run app.py

5. Open in browser
   The app will open automatically at http://localhost:8501

## Project Structure

sentiment-analyzer/
  app.py              - Main application code
  requirements.txt    - Python dependencies
  README.md           - This file

## How It Works

The app uses VADER (Valence Aware Dictionary and sEntiment Reasoner),
a rule-based sentiment analysis tool specifically designed for social media
and product review text.

### Classification Rules
- compound > 0.05  => Positive
- compound < -0.05 => Negative
- otherwise        => Neutral

## Author

[Your Name] - CS Internship Project, 2026
